package com.capstonics.prawnappapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrawnappapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrawnappapiApplication.class, args);
	}

}
